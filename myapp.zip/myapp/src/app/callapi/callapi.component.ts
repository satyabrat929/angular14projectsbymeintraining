import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-callapi',
  templateUrl: './callapi.component.html',
  styleUrls: ['./callapi.component.css']
})
export class CallapiComponent implements OnInit {
  users:any;
  constructor(private us:UserService) { 
    //us.getUsers().subscribe(u=>console.log(u))
    us.getUsers().subscribe(u=>this.users=u)
  }

  ngOnInit(): void {
  }

}
