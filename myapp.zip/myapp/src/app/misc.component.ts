import { Component } from "@angular/core";

@Component({
    selector:'misc',
    template:`
    <h1>Misc</h1>
    <img src="{{path}}"/>
    <img [src]="path"/>

    <img src="{{basepath}}lol.gif"/>
    <img src="{{basepath}}cry.gif"/>

    <button (click)="show()">click</button>

    <button (click)="show()" disabled="{{flag}}">click interpolation</button>
    <button (click)="show()" [disabled]="flag">click propertybinding</button>
    `
})
export class MiscComponent{
    flag:boolean=false
    path:string="https://hdsmileys.com/wp-content/uploads/2017/11/blush.gif"

    basepath:string="https://hdsmileys.com/wp-content/uploads/2017/11/"

    show(){
        alert('Hello')
    }
}