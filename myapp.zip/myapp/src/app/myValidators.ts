import { AbstractControl } from "@angular/forms";

export class myValidator{
    static empIdValidator(c:AbstractControl){
        if(!c.value){
          return null;
        }
        let id = c.value;
        let min=101,max=115;
        
        if(id>=min && id<=max){
         return null;
        }else{
         return {'veid':{'min':min,'max':max}}
        }
       }
}