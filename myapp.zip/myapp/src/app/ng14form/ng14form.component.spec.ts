import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ng14formComponent } from './ng14form.component';

describe('Ng14formComponent', () => {
  let component: Ng14formComponent;
  let fixture: ComponentFixture<Ng14formComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Ng14formComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Ng14formComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
