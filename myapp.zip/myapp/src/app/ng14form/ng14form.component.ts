import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-ng14form',
  template: `
    <p>
      ng14form works!
    </p>
  `,
  styles: [
  ]
})
export class Ng14formComponent implements OnInit {
  emprForm:FormGroup = new FormGroup({
    eid:new FormControl<number | null>(null), 
    ename:new FormControl()
  })
    
  constructor() { }

  ngOnInit(): void {
  }

}
