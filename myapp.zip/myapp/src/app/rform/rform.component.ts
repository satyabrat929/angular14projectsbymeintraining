import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { myValidator } from '../myValidators';

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})
export class RformComponent implements OnInit {
  emprForm:FormGroup;
  /**emprForm:FormGroup = new FormGroup({
    //eid:new FormControl(101), //default value 101 
    eid:new FormControl('',this.empIdValidator),
    //ename:new FormControl('',Validators.required)

    //ename:new FormControl('',Validators.compose([Validators.required,
   //   Validators.pattern('[a-zA-Z]{2,10}')
    //]))

    ename:new FormControl('',[Validators.required,
      Validators.pattern('[a-zA-Z]{2,10}')
    ])
  });**/
  constructor(fb:FormBuilder) { //This is from angular 6
    this.emprForm=fb.group({
      //eid:['',this.empIdValidator],//validator defined in the same component class
      eid:['',myValidator.empIdValidator], //validator accessed from the myValidator class
      ename:['abc',Validators.required]
    });
  }
  mySetValue(){
    this.emprForm.setValue({eid:101,ename:'Abhishek'}); //set value has to fill all the form , used for resetting entire form. gives error if not done for all
  }

  myPatchValue(){
    this.emprForm.patchValue({ename:'Gaurav'}); //Sets full/partial for and don't give the error.
  }

  name:string = "Satyabrat Das";
    onSubmit(data:any){
       console.log(data);
    }
  
    empIdValidator(c:AbstractControl){
     if(!c.value){
       return null;
     }
     let id = c.value;
     let min=101,max=115;
     
     if(id>=min && id<=max){
      return null;
     }else{
      return {'veid':{'min':min,'max':max}}
     }
    }
  

  ngOnInit(): void {
  }
  
}
