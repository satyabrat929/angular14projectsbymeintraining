import { Component } from "@angular/core";

@Component({
    selector:'tForm',
    template:`<h1>Template Form</h1>
    <h1>{{name}}</h1><br/>
    <form #empform='ngForm' (ngSubmit)="onSubmit(empform.value)">
        <input type="text" name="eid" placeholder="eid" required ngModel/><br/>
        <input type="text" name="ename" placeholder="ename" [(ngModel)]="name"/><br/>
        <input type="submit" [disabled]="empform.invalid"/>
    </form>
    `

})

export class TFormComponent{
    name:string = "Satyabrat Das";
    onSubmit(data:any){
       console.log(data);
    }
}