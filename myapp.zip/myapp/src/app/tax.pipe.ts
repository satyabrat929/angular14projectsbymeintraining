import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: 'taxpipe'
})

export class TaxPipe implements PipeTransform {
    transform(salary: number, rate: number = 0.2, rate1: number = 0): number {
        //result:number;
        if (salary > 0) {
            return salary * rate;

        }
        return 0;
    }


}